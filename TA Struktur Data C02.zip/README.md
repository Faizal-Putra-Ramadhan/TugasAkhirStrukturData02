Setiap perubahan dapat dicantumin di kolom komentarnya, dan untuk alasan perubahannya boleh dibahas di grup WA
